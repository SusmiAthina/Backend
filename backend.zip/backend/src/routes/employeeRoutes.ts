import { Router } from 'express';
import * as employeeController from '../controllers/employeeControllers';
const router = Router();
 
router.get('/', (req, res) => {
  res.send('Employee route is working!');
});
router.get('/', employeeController.getAllEmployees);
router.get('/:id', employeeController.getEmployeeById);
router.post('/', employeeController.addEmployee);
router.get('/search/:term', employeeController.searchEmployees);
router.get('/export/csv', employeeController.exportCSV);
 
export default router;