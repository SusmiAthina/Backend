import { Request, Response } from 'express';
import pool from '../config/db';
import { Parser } from 'json2csv';
 
export const getAllEmployees = async (req: Request, res: Response) => {
  const result = await pool.query('SELECT * FROM employees');
  res.json(result.rows);
};
 
export const getEmployeeById = async (req: Request, res: Response) => {
  const id = req.params.id;
  const result = await pool.query('SELECT * FROM employees WHERE id = $1', [id]);
  res.json(result.rows[0]);
};
 
export const addEmployee = async (req: Request, res: Response) => {
  const { name, email, skills, department, phone } = req.body;
  const result = await pool.query(
    'INSERT INTO employees (name, email, skills, department, phone) VALUES ($1, $2, $3, $4, $5) RETURNING *',
    [name, email, skills, department, phone]
  );
  res.status(201).json(result.rows[0]);
};
 
export const searchEmployees = async (req: Request, res: Response) => {
  const term = `%${req.params.term}%`;
  const result = await pool.query(
    'SELECT * FROM employees WHERE name ILIKE $1 OR $1 = ANY(skills)',
    [term]
  );
  res.json(result.rows);
};
 
export const exportCSV = async (req: Request, res: Response) => {
  const result = await pool.query('SELECT * FROM employees');
  const parser = new Parser();
  const csv = parser.parse(result.rows);
 
  res.header('Content-Type', 'text/csv');
  res.attachment('employees.csv');
  res.send(csv);
};